package theGame;

import java.awt.geom.Point2D;

import fight.Fight;
import fr.umlv.zen5.ApplicationContext;
import fr.umlv.zen5.Event;
import theGame.inventories.Item;

public class Game {
	
	private ApplicationContext ctx; 
	private GameView gameView;
	private GameData gameData;
	private TimeData timeData;
	
	/**
	 * Move the Hero on the board, 
	 * activate the loop effect, if the hero pass on the campfire
	 * and launch the fight, if there is one
	 * 
	 * @param context : Global context of the game
	 */
	private void moveHeroAndDraw(ApplicationContext context) {
		if (timeData.elapsedHero() >= TimeData.HERO_DELAY) {
			if(gameData.moveHero()) {
				gameData.loopEffect();
			}
			
			gameView.drawFrame(context, gameData, timeData);
			timeData.resetElapsedHero();
			
			if(gameData.isFight()) {
				
				Fight fight = new Fight(gameView,gameData.board(),gameData.cardInventory(),gameData.ressourcesInventory(),gameData.itemInventory(),ctx);
				if(!fight.doFight()) {
					System.out.println("Oh non le hero est mort, dommage");
					ctx.exit(0);
				}
			}
		}
	}
	
	/**
	 * Pass to the next day, if enough time has passed
	 * and activate the day effect if needed
	 * 
	 * @param ctx : Global context of the game
	 */
	private void dayAction(ApplicationContext ctx) {
		if(timeData.elapsedDay()>= TimeData.DAY_MILLISECONDS) {
			gameData.dailyEffect();
			gameView.drawFrame(ctx, gameData,timeData);
			timeData.resetelapsedDay();
		}
	}
	

	/**
	 * Main function of the Game : 
	 * Create objects which manage the display, the data and the time
	 * Then start the Game, with the funtion update (which update the screen)
	 * 
	 * @param ctx : Global context of the game
	 */
	public void Run(ApplicationContext ctx) { 
			
		this.ctx=ctx;
		this.gameView = new GameView(ctx);		
		this.gameData = new GameData();
		this.timeData = new TimeData();
		
		while(true) {
			Update(); 
		}
	}
	
	/**
	 * Function which trigger an action based on the key pressed
	 * 
	 * @param e : an event which represents the key pressed
	 */
	private void doKeyAction(Event e) {
		switch(e.getKey()) {// we get the key pressed
		
		case SPACE -> { // if it's the space bar, we stop the game
			ctx.exit(0);
		}
		
		case LEFT -> timeData.slower();
		
		case RIGHT -> timeData.faster();
		
		case S -> timeData.stop();
		
		case D -> startTime();
		
		default -> System.out.println("touche inactive "+e.getKey()); 

		}
		
	}
	
	/**
	 * Function which trigger an action based on where the player clicked
	 * 
	 * @param e : an event which represents the mouse pressed
	 */
	private void doMouseAction(Event e) {
		if (!gameData.aCardIsSelected()) { // If player hasn't selected a card before
			Point2D.Float location = e.getLocation();
			if (gameView.clickInCardZone(location)) {	// if the click is in the zone where are stocked the card
				gameData.selectCard(gameView.selectCard(location.x));
				if(gameData.selectedCardIndex()>gameData.cardInventory().cardList().size()-1) {
					gameData.unselectCard();
					gameData.unselectItem();
				}
			}
		}else {					// If the player has selected a card before
			Point2D.Float location = e.getLocation();
			if (gameView.clickInBoardZone(location)) { // Check if the click of the player is somewhere on the board, in order to place the card
				int indexY = gameView.selectLine(location.y);
				int indexX = gameView.selectColumn(location.x);
				if (gameData.placeACard(indexY,indexX)) {
					gameData.cardInventory().addCardInDeck(gameData.cardInventory().cardList().get(gameData.selectedCardIndex()));
					gameData.cardInventory().remove(gameData.selectedCardIndex());
					}
				}		
				
			gameData.unselectCard();
			gameData.unselectItem();
		}
		
		if (!gameData.anItemIsSelected()) { // If player hasn't selected an item to equip before
			Point2D.Float location = e.getLocation();
			if (gameView.clickInItemInventoryZone(location)) {	// if the click is in the zone where are stocked the items
				gameData.selectItem(gameView.selectItemInInventory(location.x, location.y)); 
				if(gameData.selectedItemIndex()>gameData.itemInventory().itemInventory().size()-1) {
					gameData.unselectItem();
					gameData.unselectCard();
				}
			}
		}else {				// If the player has selected an item before
			System.out.println("Item s�lectionn�");
			Point2D.Float location = e.getLocation();
			if (gameView.clickInStuffZone(location)) { 	// Check if the click of the player is in the hero stuff, in order to equip the item
				String key = gameView.getItemKey(location.x);
				Item selectedItem = gameData.itemInventory().itemInventory().get(gameData.selectedItemIndex());
				if (key.equals(selectedItem.type())){
					gameData.board().hero().equip(selectedItem);
					gameData.itemInventory().remove(gameData.selectedItemIndex());
				}			
			}
			gameData.unselectItem();
			gameData.unselectCard();
		}			
	}
	
	/**
	 * Function that ralaunch the passage of time 
	 */
	private void startTime() {
		timeData.start();
		gameData.unselectCard();
	}
	
	/**
	 * Update the screen display, and the differents data
	 */
	private void Update() {
		
		moveHeroAndDraw(ctx);
		dayAction(ctx);
		
		Event e = ctx.pollOrWaitEvent(200);
		
		if(e == null) return; 
		
		
		switch (e.getAction()) {
			case KEY_PRESSED:
				doKeyAction(e);
				break;
			case POINTER_DOWN:
				if (timeData.isStopped()) {
					doMouseAction(e);
				}
				break;
			default:
				break;
		}
		
		gameView.drawFrame(ctx, gameData, timeData);
		
	}
	
	
}
