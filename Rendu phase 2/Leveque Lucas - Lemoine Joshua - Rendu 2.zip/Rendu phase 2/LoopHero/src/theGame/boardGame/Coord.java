package theGame.boardGame;

public record Coord(int x,int y) {}
//Simple coord stockage