package theGame.tiles;

public class EmptyRoadSide extends AbstractTile {
	
	/**
	 * Un bord de route totalement vide
	 */
	public EmptyRoadSide() {
		super("RoadSide","");
	}

}
