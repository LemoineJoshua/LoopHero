package theGame.tiles;

public class EmptyField extends AbstractTile{
	
	/**
	 * Une case Field totalement vide
	 */
	public EmptyField() {
		super("Field","");
	}
	
}
