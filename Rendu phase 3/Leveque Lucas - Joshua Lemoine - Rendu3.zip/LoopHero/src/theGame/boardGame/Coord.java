package theGame.boardGame;

import java.io.Serializable;

public record Coord(int x,int y) implements Serializable {}
//Simple coord stockage