package theGame.boardGame;

public record Coord(int x,int y) {}
//simple stockage de coordonees